package com.spring.model;

public interface AdminDAO {

}
