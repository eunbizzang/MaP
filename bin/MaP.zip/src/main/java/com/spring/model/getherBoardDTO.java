package com.spring.model;

import lombok.Data;

@Data
public class getherBoardDTO {

	private int bno;
	private String bwriter;
	private String btitle;
	private String bcont;
	private String bcode;
	private String bupload;
	private String bdate;
	private String bredate;
	private int bhit;
	private String bsecter;
	
}
