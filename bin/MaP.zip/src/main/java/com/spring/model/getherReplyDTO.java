package com.spring.model;

import lombok.Data;

@Data
public class getherReplyDTO {

	private int rno;
	private int mno;
	private String rwriter;
	private String rcont;
	private String rdate;
	private String rredate;
	
}
