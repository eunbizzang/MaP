package com.spring.model;

public class AdminDTO {

}
