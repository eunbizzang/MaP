package com.spring.model;

import lombok.Data;

@Data
public class ReviewLikeDTO {

	private int no;
	private int bno;
	private String id;
}
