package com.spring.model;

import lombok.Data;

@Data
public class Free_boardDTO {

	private int bno;
	private String btitle;
	private String bwriter;
	private String bcont;
	private String bcode;
	private String bupload;
	private int bhit;
	private String bdate;
	private String bredate;
	private String buploadd;
}
