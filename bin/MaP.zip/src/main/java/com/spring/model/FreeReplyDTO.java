package com.spring.model;

import lombok.Data;

@Data
public class FreeReplyDTO {
	
	private int no;
	private int bno;
	private String rwriter;
	private String rcont;
	private String rdate;
	private String rredate;
	
}
